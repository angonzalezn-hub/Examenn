productos = {
    'M001': ['Alimento Premium', 'comida', 'DogPlus', 10, True, False],
    'M002': ['Arena Aglomerante', 'higiene', 'CatClean', 8, False, False],
    'M003': ['Snack Dental', 'snack', 'BiteJoy', 1, True, True],
    'M004': ['Shampoo Suave', 'higiene', 'PetCare', 0.5, False, True],
    'M005': ['Correa Nylon', 'accesorio', 'WalkPro', 0.3, True, False],
    'M006': ['Cama Mediana', 'accesorio', 'CozyPet', 2, False, False],
} 

stock = {
    'M001': [32990, 12],
    'M002': [9990, 0],
    'M003': [5490, 25],
    'M004': [7990, 5],
    'M005': [11990, 7],
    'M006': [24990, 3],
}

def leer_opcion():
    while True:
        try:
            op = int(input("Ingrese opcion: "))
            if 1 <= op <= 6:
                return op
            print("Debe seleccionar una opcion valida")
        except ValueError:
            print("Debe seleccionar una opcion valida")

def buscar_codigo(codigo, diccionario):
    for cod in diccionario.keys():
        if cod.upper() == codigo.upper():
            return True
    return False

def unidades_categoria(categoria, productos, stock):
    total = 0
    for cod, datos in productos.items():
        if datos[1].lower() == categoria.strip().lower():
            total += stock[cod][1]
    print(f"El total de unidades disponibles es: {total}")

def busqueda_precio(p_min, p_max, productos, stock):
    enc = []
    for cod, datos in sotck.items():
        if p_min <= datos[0] <= p_max and datos[1] > 0:
            enc.append(f"{productos[cod][0]}--{cod}")

    if enc:
        enc.sort()
        print(f"Los productos encontrados son: {enc}")
    else:
        print("No hay productos en ese rango de precios.")

def actualizar_precio(codigo, nuevo_precio, stock):
    if buscar_codigo(codigo, stock):
        stock[codigo.upper()][0] = nuevo_precio
        return True
    return False    

def agregar_producto(codigo, nombre, categoria, marca, peso, importado, cachorro, precio, unidades, productos, stock):
    cod = codigo.upper()
    productos[cod] = [nombre, categoria, marca, peso, importado, cachorro]
    stock[cod] = [precio, unidades]
    return True

def eliminar_producto(codigo, productos, stock):
    if buscar_codigo(codigo, productos):
        cod = codigo.upper()
        productos.pop(cod)
        stock.pop(cod)
        return True
    return False

while True:
    print("\n========== MENÚ PRINCIPAL ==========")
    print("1. Unidades por categoría")
    print("2. Búsqueda de productos por rango de precio")
    print("3. Actualizar precio de producto")
    print("4. Agregar producto")
    print("5. Eliminar producto")
    print("6. Salir")
    print("=====================================")

    opcion = leer_opcion()

    match opcion:
        case 1:
            cat = input("Ingrese categoria a consultar: ")
            unidades_categoria(cat, productos, stock)

        case 2:
            while True:
                try:
                    pmin = int(input("Ingrese el precio minimo: "))
                    pmax = int(input("Ingrese el precio maximo: "))
                    if 0 <= pmin <= pmax:
                        busqueda_precio(pmin, pmax, productos, stock)
                        break
                    print("Los precios deben ser mayor o igual a 0.")
                except ValueError:
                    print("Debe ingresar valores enteros")

        case 3:
            while True: 
                cod = input("Ingrese codigo del producto: ")
                try:
                    np = int(input("Ingrese nuevo precio: "))
                    if np > 0:
                        if actualizar_precio(cod, np, stock): 
                            print("Precio actualizado")
                        else: 
                            print("El código no existe")
                    else: 
                        print("El precio debe ser un número entero positivo.")
                except ValueError: 
                    print("Debe ingresar un valor entero válido.")
                    
                if input("¿Desea actualizar otro precio (s/n)?: ").lower() != 's': 
                    break

        case 4:
            cod = input("Ingrese código del producto: ")
            if cod.strip() == "" or buscar_codigo(cod, productos):
                print("Error: Código inválido o ya existe.")
                continue
                
            n = input("Ingrese nombre: ")
            c = input("Ingrese categoría: ")
            m = input("Ingrese marca: ")
            
            if n.strip() == "" or c.strip() == "" or m.strip() == "":
                print("Error: Los textos no pueden estar vacíos.")
                continue

            try:
                peso = float(input("Ingrese peso (kg): "))
                imp = input("¿Es importado? (s/n): ").lower()
                cach = input("¿Es para cachorro? (s/n): ").lower()
                p = int(input("Ingrese precio: "))
                u = int(input("Ingrese unidades: "))
                

                if peso > 0 and p > 0 and u >= 0 and imp in ['s', 'n'] and cach in ['s', 'n']:
                    agregar_producto(cod, n, c, m, peso, imp == 's', cach == 's', p, u, productos, stock)
                    print("Producto agregado")
                else:
                    print("Error: Valores fuera de rango o respuestas distintas a 's' o 'n'.")
            except ValueError:
                print("Error: El peso, precio y unidades deben ser numéricos.")
            
        case 5:
            cod = input("Ingrese código del producto a eliminar: ")
            if eliminar_producto(cod, productos, stock): 
                print("Producto eliminado")
            else: 
                print("El código no existe")
            
        case 6:
            print("Programa finalizado.")
            break





























while True:

    print("========== MENÚ PRINCIPAL ==========")
    print("1. Unidades por categoría")
    print("2. Búsqueda de productos por rango de precio")
    print("3. Actualizar precio de producto")
    print("4. Agregar producto")
    print("5. Eliminar producto")
    print("6. Salir")
    print("=====================================")

    op = input("Seleccione opcion: ")





